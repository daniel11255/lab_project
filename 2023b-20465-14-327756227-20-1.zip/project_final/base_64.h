char* decimal_to_base64(int decimalNumber);
